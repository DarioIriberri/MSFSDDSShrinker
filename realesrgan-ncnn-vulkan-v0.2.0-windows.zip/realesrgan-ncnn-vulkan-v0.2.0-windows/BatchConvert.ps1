.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_1.PNG.png" -o ".\LFRS_GROUND_PH_1_16K.png" -n realesrgan-x4plus -s 4 -t 512
.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_2.PNG.png" -o ".\LFRS_GROUND_PH_2_16K.png" -n realesrgan-x4plus -s 4 -t 512
.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_3.PNG.png" -o ".\LFRS_GROUND_PH_3_16K.png" -n realesrgan-x4plus -s 4 -t 512
.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_4.PNG.png" -o ".\LFRS_GROUND_PH_4_16K.png" -n realesrgan-x4plus -s 4 -t 512
.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_5.PNG.png" -o ".\LFRS_GROUND_PH_5_16K.png" -n realesrgan-x4plus -s 4 -t 512
.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_6.PNG.png" -o ".\LFRS_GROUND_PH_6_16K.png" -n realesrgan-x4plus -s 4 -t 512
.\realesrgan-ncnn-vulkan.exe -i ".\LFRS_GROUND_PH_7.PNG.png" -o ".\LFRS_GROUND_PH_7_16K.png" -n realesrgan-x4plus -s 4 -t 512